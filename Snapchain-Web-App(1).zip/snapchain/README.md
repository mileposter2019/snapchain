# Snapchain

Snapchain is a Linktree-style platform for cryptocurrency enthusiasts to share their wallet addresses and receive donations. The platform allows users to create a personalized profile page with QR codes for easy scanning and direct donations.

## Features

- User authentication and registration
- Secure profile management
- Support for Bitcoin (BTC), Ethereum (ETH), and Terra Luna Classic (LUNC)
- QR code generation for wallet addresses
- Analytics dashboard for tracking page views and donations
- Customizable profile URLs
- Subscription tiers (Free, Basic, Pro)
- Mobile-first responsive design

## Technologies Used

- Node.js (Express.js)
- EJS templating
- CSS Grid for responsive layouts
- bcrypt for password hashing
- QR code generation
- Crypto APIs (Etherscan, Blockchain.com, Terra Finder)
- Stripe payment integration

## Getting Started

### Installation

1. Clone the repository:
```
git clone https://github.com/yourusername/snapchain.git
cd snapchain
```

2. Install dependencies:
```
npm install
```

3. Set up environment variables:
Create a `.env` file in the root directory with the following variables:
```
PORT=3000
PASSWORD_HASH_SECRET=your_password_hash_secret
SESSION_SECRET=your_session_secret
STRIPE_SECRET_KEY=your_stripe_secret_key
ETHERSCAN_API_KEY=your_etherscan_api_key
BLOCKCHAINCOM_API_KEY=your_blockchaincom_api_key
TERRAFINDER_API_KEY=your_terrafinder_api_key
```

### Running the Application

Start the development server:
```
npm run dev
```

The application will be available at `http://localhost:3000`.

## Deployment

This application is configured for deployment on Netlify. To deploy:

1. Push your code to a Git repository
2. Connect the repository to Netlify
3. Configure the build settings as specified in `netlify.toml`

## License

This project is licensed under the MIT License.
