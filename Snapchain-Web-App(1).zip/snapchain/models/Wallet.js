import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';
import QRCode from 'qrcode';
import axios from 'axios';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const WALLETS_FILE = path.join(__dirname, '../data/wallets.json');

// Wallet types
export const WALLET_TYPES = {
  BTC: 'bitcoin',
  ETH: 'ethereum',
  LUNC: 'terra-luna-classic'
};

export default class Wallet {
  constructor(data) {
    this.id = data.id;
    this.userId = data.userId;
    this.type = data.type;
    this.address = data.address;
    this.label = data.label || '';
    this.createdAt = data.createdAt || new Date().toISOString();
    this.qrCode = data.qrCode || null;
    this.displayOnProfile = data.displayOnProfile !== undefined ? data.displayOnProfile : true;
    this.donationCount = data.donationCount || 0;
    this.donationTotal = data.donationTotal || 0;
  }

  // Save wallet to JSON file
  async save() {
    try {
      let wallets = JSON.parse(await fs.readFile(WALLETS_FILE, 'utf8'));

      const existingIndex = wallets.findIndex(wallet => wallet.id === this.id);

      if (existingIndex !== -1) {
        // Update existing wallet
        wallets[existingIndex] = this;
      } else {
        // Add new wallet
        wallets.push(this);
      }

      await fs.writeFile(WALLETS_FILE, JSON.stringify(wallets, null, 2));
      return true;
    } catch (error) {
      console.error('Error saving wallet:', error);
      return false;
    }
  }

  // Generate QR code for wallet address
  async generateQRCode() {
    try {
      // Generate QR code data URL
      const qrCodeDataUrl = await QRCode.toDataURL(this.address);
      this.qrCode = qrCodeDataUrl;

      // Save updated wallet
      await this.save();

      return qrCodeDataUrl;
    } catch (error) {
      console.error('Error generating QR code:', error);
      return null;
    }
  }

  // Get current wallet balance
  async getBalance() {
    try {
      let balance = 0;

      // Get balance based on wallet type
      switch (this.type) {
        case WALLET_TYPES.BTC:
          balance = await this.getBTCBalance();
          break;
        case WALLET_TYPES.ETH:
          balance = await this.getETHBalance();
          break;
        case WALLET_TYPES.LUNC:
          balance = await this.getLUNCBalance();
          break;
        default:
          balance = 0;
      }

      return balance;
    } catch (error) {
      console.error('Error getting wallet balance:', error);
      return 0;
    }
  }

  // Get Bitcoin balance
  async getBTCBalance() {
    try {
      const response = await axios.get(`https://blockchain.info/rawaddr/${this.address}?api_key=${process.env.BLOCKCHAINCOM_API_KEY}`);
      const balance = response.data.final_balance / 100000000; // Convert satoshis to BTC
      return balance;
    } catch (error) {
      console.error('Error getting BTC balance:', error);
      return 0;
    }
  }

  // Get Ethereum balance
  async getETHBalance() {
    try {
      const response = await axios.get(`https://api.etherscan.io/api?module=account&action=balance&address=${this.address}&tag=latest&apikey=${process.env.ETHERSCAN_API_KEY}`);

      if (response.data.status === '1') {
        const balance = parseInt(response.data.result) / 1000000000000000000; // Convert wei to ETH
        return balance;
      }

      return 0;
    } catch (error) {
      console.error('Error getting ETH balance:', error);
      return 0;
    }
  }

  // Get Terra Luna Classic balance
  async getLUNCBalance() {
    try {
      // Terra Finder API requires specific implementation
      // For now, we'll just return 0
      return 0;
    } catch (error) {
      console.error('Error getting LUNC balance:', error);
      return 0;
    }
  }

  // Convert balance to USD
  async getUSDValue() {
    try {
      let price = 0;
      let balance = await this.getBalance();

      // Get price based on wallet type
      switch (this.type) {
        case WALLET_TYPES.BTC:
          price = await this.getBTCPrice();
          break;
        case WALLET_TYPES.ETH:
          price = await this.getETHPrice();
          break;
        case WALLET_TYPES.LUNC:
          price = await this.getLUNCPrice();
          break;
        default:
          price = 0;
      }

      return balance * price;
    } catch (error) {
      console.error('Error getting USD value:', error);
      return 0;
    }
  }

  // Get Bitcoin price
  async getBTCPrice() {
    try {
      const response = await axios.get('https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd');
      return response.data.bitcoin.usd;
    } catch (error) {
      console.error('Error getting BTC price:', error);
      return 0;
    }
  }

  // Get Ethereum price
  async getETHPrice() {
    try {
      const response = await axios.get('https://api.coingecko.com/api/v3/simple/price?ids=ethereum&vs_currencies=usd');
      return response.data.ethereum.usd;
    } catch (error) {
      console.error('Error getting ETH price:', error);
      return 0;
    }
  }

  // Get Terra Luna Classic price
  async getLUNCPrice() {
    try {
      const response = await axios.get('https://api.coingecko.com/api/v3/simple/price?ids=terra-luna-classic&vs_currencies=usd');
      return response.data['terra-luna-classic'].usd;
    } catch (error) {
      console.error('Error getting LUNC price:', error);
      return 0;
    }
  }

  // Find wallet by ID
  static async findById(id) {
    try {
      const wallets = JSON.parse(await fs.readFile(WALLETS_FILE, 'utf8'));
      const wallet = wallets.find(wallet => wallet.id === id);

      return wallet ? new Wallet(wallet) : null;
    } catch (error) {
      console.error('Error finding wallet by ID:', error);
      return null;
    }
  }

  // Find wallets by user ID
  static async findByUserId(userId) {
    try {
      const wallets = JSON.parse(await fs.readFile(WALLETS_FILE, 'utf8'));
      const userWallets = wallets.filter(wallet => wallet.userId === userId);

      return userWallets.map(wallet => new Wallet(wallet));
    } catch (error) {
      console.error('Error finding wallets by user ID:', error);
      return [];
    }
  }

  // Create new wallet
  static async create({ userId, type, address, label, displayOnProfile }) {
    try {
      // Check if wallet already exists for this user
      const wallets = JSON.parse(await fs.readFile(WALLETS_FILE, 'utf8'));
      const existingWallet = wallets.find(
        wallet => wallet.userId === userId &&
                 wallet.type === type &&
                 wallet.address.toLowerCase() === address.toLowerCase()
      );

      if (existingWallet) {
        return { success: false, message: 'Wallet already exists' };
      }

      // Generate unique ID
      const id = Date.now().toString();

      // Create new wallet
      const newWallet = new Wallet({
        id,
        userId,
        type,
        address,
        label: label || '',
        displayOnProfile: displayOnProfile !== undefined ? displayOnProfile : true
      });

      // Generate QR code
      await newWallet.generateQRCode();

      // Save wallet
      await newWallet.save();

      return { success: true, wallet: newWallet };
    } catch (error) {
      console.error('Error creating wallet:', error);
      return { success: false, message: 'Error creating wallet' };
    }
  }

  // Update wallet data
  async update(data) {
    try {
      // Update wallet data
      Object.keys(data).forEach(key => {
        // Don't update id, userId, type, and address here
        if (key !== 'id' && key !== 'userId' && key !== 'type' && key !== 'address') {
          this[key] = data[key];
        }
      });

      // Save updated wallet
      await this.save();

      return { success: true, wallet: this };
    } catch (error) {
      console.error('Error updating wallet:', error);
      return { success: false, message: 'Error updating wallet' };
    }
  }

  // Delete wallet
  async delete() {
    try {
      let wallets = JSON.parse(await fs.readFile(WALLETS_FILE, 'utf8'));

      // Filter out this wallet
      wallets = wallets.filter(wallet => wallet.id !== this.id);

      // Save updated wallets
      await fs.writeFile(WALLETS_FILE, JSON.stringify(wallets, null, 2));

      return { success: true };
    } catch (error) {
      console.error('Error deleting wallet:', error);
      return { success: false, message: 'Error deleting wallet' };
    }
  }

  // Get public wallet data (for profiles)
  getPublicData() {
    return {
      id: this.id,
      type: this.type,
      address: this.address,
      label: this.label,
      qrCode: this.qrCode
    };
  }

  // Record donation
  async recordDonation(amount) {
    try {
      this.donationCount++;
      this.donationTotal += amount;

      // Save updated wallet
      await this.save();

      return { success: true };
    } catch (error) {
      console.error('Error recording donation:', error);
      return { success: false, message: 'Error recording donation' };
    }
  }
}
