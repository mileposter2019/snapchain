import express from 'express';
import helmet from 'helmet';
import cookieParser from 'cookie-parser';
import session from 'express-session';
import { fileURLToPath } from 'url';
import path from 'path';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

// Routes imports
import authRoutes from './routes/auth.js';
import profileRoutes from './routes/profile.js';
import walletRoutes from './routes/wallets.js';
import dashboardRoutes from './routes/dashboard.js';
import apiRoutes from './routes/api.js';

// Models imports
import User from './models/User.js';
import Wallet from './models/Wallet.js';

// Middleware imports
import { checkAuthenticated } from './middleware/auth.js';

const app = express();
const PORT = process.env.PORT || 3000;

// Get current directory
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Express configuration
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Security middleware
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com"],
      scriptSrc: ["'self'", "'unsafe-inline'", "https://js.stripe.com"],
      connectSrc: ["'self'", "https://api.stripe.com"],
      frameSrc: ["'self'", "https://js.stripe.com", "https://hooks.stripe.com"],
      imgSrc: ["'self'", "data:", "https:"],
    },
  },
}));

// Basic middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(session({
  secret: process.env.SESSION_SECRET || 'default_session_secret',
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: process.env.NODE_ENV === 'production',
    httpOnly: true,
    maxAge: 24 * 60 * 60 * 1000, // 24 hours
  },
}));

// Static files
app.use(express.static(path.join(__dirname, 'public')));

// Routes
app.use('/auth', authRoutes);
app.use('/profile', checkAuthenticated, profileRoutes);
app.use('/wallets', checkAuthenticated, walletRoutes);
app.use('/dashboard', checkAuthenticated, dashboardRoutes);
app.use('/api', apiRoutes);

// Home route
app.get('/', (req, res) => {
  res.render('index', {
    user: req.session.user || null,
    title: 'Snapchain - Share Your Crypto Addresses'
  });
});

// Public profile route
app.get('/:profileUrl', async (req, res) => {
  try {
    const { profileUrl } = req.params;

    // Check if this is a known route
    if (['auth', 'profile', 'wallets', 'dashboard', 'api'].includes(profileUrl)) {
      return next();
    }

    // Find user by profile URL
    const user = await User.findByProfileUrl(profileUrl);

    if (!user) {
      return res.status(404).render('error', {
        title: '404 - Profile Not Found',
        message: 'Profile not found',
        user: req.session.user || null
      });
    }

    // Increment page views
    await user.incrementPageViews();

    // Get wallets that are displayed on profile
    const allWallets = await Wallet.findByUserId(user.id);
    const wallets = allWallets.filter(wallet => wallet.displayOnProfile);

    // Render public profile
    res.render('public-profile', {
      title: `${user.username} - Snapchain`,
      profile: {
        username: user.username,
        profileUrl: user.profileUrl
      },
      wallets,
      user: req.session.user || null,
      isPreview: false
    });
  } catch (error) {
    console.error('Error loading public profile:', error);
    res.status(500).render('error', {
      title: 'Error',
      message: 'An error occurred while loading this profile',
      user: req.session.user || null
    });
  }
});

// 404 route
app.use((req, res) => {
  res.status(404).render('error', {
    message: 'Page not found',
    title: '404 - Page Not Found',
    user: req.session.user || null
  });
});

// Error handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).render('error', {
    message: 'Something went wrong!',
    title: 'Error',
    user: req.session.user || null
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
