import express from 'express';
import User from '../models/User.js';
import Wallet from '../models/Wallet.js';

const router = express.Router();

// Profile settings
router.get('/', async (req, res) => {
  try {
    // Get user
    const user = await User.findById(req.session.user.id);

    if (!user) {
      return res.redirect('/auth/logout');
    }

    res.render('profile/settings', {
      title: 'Profile Settings - Snapchain',
      user: req.session.user,
      profileUrl: user.profileUrl,
      publicUrl: `${req.protocol}://${req.get('host')}/${user.profileUrl}`,
      error: req.query.error || null,
      success: req.query.success || null
    });
  } catch (error) {
    console.error('Error loading profile settings:', error);
    res.render('profile/settings', {
      title: 'Profile Settings - Snapchain',
      user: req.session.user,
      profileUrl: req.session.user.profileUrl,
      publicUrl: `${req.protocol}://${req.get('host')}/${req.session.user.profileUrl}`,
      error: 'An error occurred while loading your profile settings'
    });
  }
});

// Update profile
router.post('/update', async (req, res) => {
  try {
    const { profileUrl } = req.body;

    // Validate input
    if (!profileUrl) {
      return res.redirect('/profile?error=Profile+URL+is+required');
    }

    // Validate profile URL (alphanumeric and hyphens only)
    if (!/^[a-zA-Z0-9-]+$/.test(profileUrl)) {
      return res.redirect('/profile?error=Profile+URL+can+only+contain+letters,+numbers,+and+hyphens');
    }

    // Get user
    const user = await User.findById(req.session.user.id);

    if (!user) {
      return res.redirect('/auth/logout');
    }

    // Check if profile URL is already taken by another user
    if (profileUrl !== user.profileUrl) {
      const existingUser = await User.findByProfileUrl(profileUrl);

      if (existingUser && existingUser.id !== user.id) {
        return res.redirect('/profile?error=Profile+URL+is+already+taken');
      }
    }

    // Update user
    const result = await user.update({
      profileUrl
    });

    if (!result.success) {
      return res.redirect(`/profile?error=${encodeURIComponent(result.message)}`);
    }

    // Update session data
    req.session.user.profileUrl = profileUrl;

    // Redirect to profile settings with success message
    res.redirect('/profile?success=Profile+updated+successfully');
  } catch (error) {
    console.error('Error updating profile:', error);
    res.redirect('/profile?error=An+unexpected+error+occurred');
  }
});

// Change password
router.get('/change-password', (req, res) => {
  res.render('profile/change-password', {
    title: 'Change Password - Snapchain',
    user: req.session.user,
    error: req.query.error || null,
    success: req.query.success || null
  });
});

// Change password POST
router.post('/change-password', async (req, res) => {
  try {
    const { currentPassword, newPassword, confirmPassword } = req.body;

    // Validate input
    if (!currentPassword || !newPassword || !confirmPassword) {
      return res.redirect('/profile/change-password?error=Please+fill+all+required+fields');
    }

    if (newPassword !== confirmPassword) {
      return res.redirect('/profile/change-password?error=New+passwords+do+not+match');
    }

    if (newPassword.length < 8) {
      return res.redirect('/profile/change-password?error=New+password+must+be+at+least+8+characters+long');
    }

    // Get user
    const user = await User.findById(req.session.user.id);

    if (!user) {
      return res.redirect('/auth/logout');
    }

    // Update password
    const result = await user.updatePassword(currentPassword, newPassword);

    if (!result.success) {
      return res.redirect(`/profile/change-password?error=${encodeURIComponent(result.message)}`);
    }

    // Redirect to profile settings with success message
    res.redirect('/profile?success=Password+changed+successfully');
  } catch (error) {
    console.error('Error changing password:', error);
    res.redirect('/profile/change-password?error=An+unexpected+error+occurred');
  }
});

// View public profile
router.get('/preview', async (req, res) => {
  try {
    // Get user
    const user = await User.findById(req.session.user.id);

    if (!user) {
      return res.redirect('/auth/logout');
    }

    // Get wallets
    const allWallets = await Wallet.findByUserId(user.id);
    const wallets = allWallets.filter(wallet => wallet.displayOnProfile);

    res.render('profile/preview', {
      title: `${user.username} - Snapchain`,
      user: req.session.user,
      profile: {
        username: user.username,
        profileUrl: user.profileUrl
      },
      wallets,
      isPreview: true
    });
  } catch (error) {
    console.error('Error loading profile preview:', error);
    res.redirect('/profile?error=An+error+occurred+while+loading+your+profile+preview');
  }
});

export default router;
