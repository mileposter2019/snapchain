import express from 'express';
import User from '../models/User.js';
import Wallet from '../models/Wallet.js';

const router = express.Router();

// Public profile API
router.get('/profile/:profileUrl', async (req, res) => {
  try {
    const { profileUrl } = req.params;

    // Find user by profile URL
    const user = await User.findByProfileUrl(profileUrl);

    if (!user) {
      return res.status(404).json({ success: false, message: 'Profile not found' });
    }

    // Increment page views
    await user.incrementPageViews();

    // Get wallets that are displayed on profile
    const allWallets = await Wallet.findByUserId(user.id);
    const wallets = allWallets
      .filter(wallet => wallet.displayOnProfile)
      .map(wallet => wallet.getPublicData());

    // Return public profile data
    res.json({
      success: true,
      profile: {
        username: user.username,
        profileUrl: user.profileUrl,
        wallets
      }
    });
  } catch (error) {
    console.error('Error getting public profile:', error);
    res.status(500).json({ success: false, message: 'An unexpected error occurred' });
  }
});

// Record donation
router.post('/donation/:walletId', async (req, res) => {
  try {
    const { walletId } = req.params;
    const { amount } = req.body;

    // Validate input
    if (!amount || isNaN(parseFloat(amount)) || parseFloat(amount) <= 0) {
      return res.status(400).json({ success: false, message: 'Invalid donation amount' });
    }

    // Get wallet
    const wallet = await Wallet.findById(walletId);

    if (!wallet) {
      return res.status(404).json({ success: false, message: 'Wallet not found' });
    }

    // Record donation
    const result = await wallet.recordDonation(parseFloat(amount));

    if (!result.success) {
      return res.status(500).json({ success: false, message: result.message });
    }

    // Return success
    res.json({ success: true, message: 'Donation recorded successfully' });
  } catch (error) {
    console.error('Error recording donation:', error);
    res.status(500).json({ success: false, message: 'An unexpected error occurred' });
  }
});

// Get wallet balance
router.get('/wallet/:walletId/balance', async (req, res) => {
  try {
    const { walletId } = req.params;

    // Get wallet
    const wallet = await Wallet.findById(walletId);

    if (!wallet) {
      return res.status(404).json({ success: false, message: 'Wallet not found' });
    }

    // Get balance
    const balance = await wallet.getBalance();
    const usdValue = await wallet.getUSDValue();

    // Return balance
    res.json({
      success: true,
      wallet: {
        id: wallet.id,
        type: wallet.type,
        balance,
        usdValue
      }
    });
  } catch (error) {
    console.error('Error getting wallet balance:', error);
    res.status(500).json({ success: false, message: 'An unexpected error occurred' });
  }
});

export default router;
