import express from 'express';
import User, { SUBSCRIPTION_FEATURES, SUBSCRIPTION_PLANS } from '../models/User.js';
import Wallet from '../models/Wallet.js';

const router = express.Router();

// Dashboard
router.get('/', async (req, res) => {
  try {
    // Get user
    const user = await User.findById(req.session.user.id);

    if (!user) {
      return res.redirect('/auth/logout');
    }

    // Get wallets
    const wallets = await Wallet.findByUserId(user.id);

    // Get subscription features
    const subscriptionFeatures = SUBSCRIPTION_FEATURES[user.subscription];

    // Calculate analytics
    let totalDonations = 0;
    let totalDonationAmount = 0;
    let walletBalances = [];

    for (const wallet of wallets) {
      totalDonations += wallet.donationCount;
      totalDonationAmount += wallet.donationTotal;

      // Get wallet balance
      try {
        const balance = await wallet.getBalance();
        const usdValue = await wallet.getUSDValue();

        walletBalances.push({
          id: wallet.id,
          type: wallet.type,
          address: wallet.address,
          label: wallet.label,
          balance,
          usdValue
        });
      } catch (error) {
        console.error('Error getting wallet balance:', error);

        walletBalances.push({
          id: wallet.id,
          type: wallet.type,
          address: wallet.address,
          label: wallet.label,
          balance: 0,
          usdValue: 0
        });
      }
    }

    res.render('dashboard/index', {
      title: 'Dashboard - Snapchain',
      user: req.session.user,
      pageViews: user.pageViews,
      walletCount: wallets.length,
      totalDonations,
      totalDonationAmount,
      walletBalances,
      subscription: user.subscription,
      subscriptionFeatures,
      subscriptionExpiry: user.subscriptionExpiry,
      error: req.query.error || null,
      success: req.query.success || null,
      analytics: subscriptionFeatures.analytics
    });
  } catch (error) {
    console.error('Error loading dashboard:', error);
    res.render('dashboard/index', {
      title: 'Dashboard - Snapchain',
      user: req.session.user,
      pageViews: 0,
      walletCount: 0,
      totalDonations: 0,
      totalDonationAmount: 0,
      walletBalances: [],
      subscription: req.session.user.subscription,
      subscriptionFeatures: SUBSCRIPTION_FEATURES[req.session.user.subscription],
      subscriptionExpiry: null,
      error: 'An error occurred while loading your dashboard',
      analytics: SUBSCRIPTION_FEATURES[req.session.user.subscription].analytics
    });
  }
});

// Subscriptions
router.get('/subscription', async (req, res) => {
  try {
    // Get user
    const user = await User.findById(req.session.user.id);

    if (!user) {
      return res.redirect('/auth/logout');
    }

    // Get subscription features
    const subscriptionFeatures = SUBSCRIPTION_FEATURES[user.subscription];

    res.render('dashboard/subscription', {
      title: 'Subscription - Snapchain',
      user: req.session.user,
      subscription: user.subscription,
      subscriptionFeatures,
      subscriptionExpiry: user.subscriptionExpiry,
      plans: SUBSCRIPTION_PLANS,
      planFeatures: SUBSCRIPTION_FEATURES,
      error: req.query.error || null,
      success: req.query.success || null
    });
  } catch (error) {
    console.error('Error loading subscription page:', error);
    res.render('dashboard/subscription', {
      title: 'Subscription - Snapchain',
      user: req.session.user,
      subscription: req.session.user.subscription,
      subscriptionFeatures: SUBSCRIPTION_FEATURES[req.session.user.subscription],
      subscriptionExpiry: null,
      plans: SUBSCRIPTION_PLANS,
      planFeatures: SUBSCRIPTION_FEATURES,
      error: 'An error occurred while loading your subscription details'
    });
  }
});

// Update subscription
router.post('/subscription/update', async (req, res) => {
  try {
    const { plan } = req.body;

    // Validate input
    if (!plan || !Object.values(SUBSCRIPTION_PLANS).includes(plan)) {
      return res.redirect('/dashboard/subscription?error=Invalid+subscription+plan');
    }

    // Get user
    const user = await User.findById(req.session.user.id);

    if (!user) {
      return res.redirect('/auth/logout');
    }

    // For free plan, update subscription immediately
    if (plan === SUBSCRIPTION_PLANS.FREE) {
      const result = await user.updateSubscription(plan, null, null);

      if (!result.success) {
        return res.redirect(`/dashboard/subscription?error=${encodeURIComponent(result.message)}`);
      }

      // Update session data
      req.session.user.subscription = plan;

      // Redirect to subscription page with success message
      return res.redirect('/dashboard/subscription?success=Subscription+updated+to+Free+plan');
    }

    // For paid plans, redirect to payment page
    // In a real application, this would redirect to Stripe checkout
    const planName = plan === SUBSCRIPTION_PLANS.BASIC ? 'Basic' : 'Pro';
    const planPrice = SUBSCRIPTION_FEATURES[plan].price;

    res.render('dashboard/payment', {
      title: 'Subscribe - Snapchain',
      user: req.session.user,
      plan,
      planName,
      planPrice,
      features: SUBSCRIPTION_FEATURES[plan],
      error: req.query.error || null
    });
  } catch (error) {
    console.error('Error updating subscription:', error);
    res.redirect('/dashboard/subscription?error=An+unexpected+error+occurred');
  }
});

// Process payment (simulated)
router.post('/subscription/payment', async (req, res) => {
  try {
    const { plan } = req.body;

    // Validate input
    if (!plan || !Object.values(SUBSCRIPTION_PLANS).includes(plan)) {
      return res.redirect('/dashboard/subscription?error=Invalid+subscription+plan');
    }

    // Get user
    const user = await User.findById(req.session.user.id);

    if (!user) {
      return res.redirect('/auth/logout');
    }

    // In a real application, this would process the payment through Stripe
    // and set up a subscription

    // For now, just simulate a successful payment and update the subscription

    // Set subscription expiry date (1 month from now)
    const expiryDate = new Date();
    expiryDate.setMonth(expiryDate.getMonth() + 1);

    // Update subscription
    const result = await user.updateSubscription(
      plan,
      expiryDate.toISOString(),
      'simulated_stripe_customer_id'
    );

    if (!result.success) {
      return res.redirect(`/dashboard/subscription?error=${encodeURIComponent(result.message)}`);
    }

    // Update session data
    req.session.user.subscription = plan;

    // Redirect to subscription page with success message
    const planName = plan === SUBSCRIPTION_PLANS.BASIC ? 'Basic' : 'Pro';
    res.redirect(`/dashboard/subscription?success=Subscription+updated+to+${planName}+plan`);
  } catch (error) {
    console.error('Error processing payment:', error);
    res.redirect('/dashboard/subscription?error=An+unexpected+error+occurred');
  }
});

// Cancel subscription
router.post('/subscription/cancel', async (req, res) => {
  try {
    // Get user
    const user = await User.findById(req.session.user.id);

    if (!user) {
      return res.redirect('/auth/logout');
    }

    // In a real application, this would cancel the subscription in Stripe

    // Update subscription to free plan
    const result = await user.updateSubscription(SUBSCRIPTION_PLANS.FREE, null, null);

    if (!result.success) {
      return res.redirect(`/dashboard/subscription?error=${encodeURIComponent(result.message)}`);
    }

    // Update session data
    req.session.user.subscription = SUBSCRIPTION_PLANS.FREE;

    // Redirect to subscription page with success message
    res.redirect('/dashboard/subscription?success=Subscription+cancelled+successfully');
  } catch (error) {
    console.error('Error cancelling subscription:', error);
    res.redirect('/dashboard/subscription?error=An+unexpected+error+occurred');
  }
});

export default router;
