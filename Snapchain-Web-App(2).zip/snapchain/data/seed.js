import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';
import bcrypt from 'bcrypt';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const USERS_FILE = path.join(__dirname, 'users.json');
const WALLETS_FILE = path.join(__dirname, 'wallets.json');

// Demo user data
const users = [
  {
    id: '1688483941264',
    username: 'demo_user',
    email: 'demo@example.com',
    password: await bcrypt.hash('demo123', 10),
    profileUrl: 'demo',
    createdAt: new Date().toISOString(),
    subscription: 'basic',
    subscriptionExpiry: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(), // 30 days from now
    stripeCustomerId: 'cus_demo123',
    lastLogin: new Date().toISOString(),
    pageViews: 42
  },
  {
    id: '1688483941265',
    username: 'crypto_enthusiast',
    email: 'crypto@example.com',
    password: await bcrypt.hash('crypto123', 10),
    profileUrl: 'crypto',
    createdAt: new Date(Date.now() - 60 * 24 * 60 * 60 * 1000).toISOString(), // 60 days ago
    subscription: 'pro',
    subscriptionExpiry: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString(), // 90 days from now
    stripeCustomerId: 'cus_crypto123',
    lastLogin: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(), // 2 days ago
    pageViews: 157
  }
];

// Demo wallet data
const wallets = [
  {
    id: '1688483951264',
    userId: '1688483941264',
    type: 'bitcoin',
    address: '3FZbgi29cpjq2GjdwV8eyHuJJnkLtktZc5',
    label: 'My Bitcoin Wallet',
    createdAt: new Date().toISOString(),
    qrCode: null,
    displayOnProfile: true,
    donationCount: 3,
    donationTotal: 0.00123
  },
  {
    id: '1688483951265',
    userId: '1688483941264',
    type: 'ethereum',
    address: '0x71C7656EC7ab88b098defB751B7401B5f6d8976F',
    label: 'ETH Donations',
    createdAt: new Date().toISOString(),
    qrCode: null,
    displayOnProfile: true,
    donationCount: 1,
    donationTotal: 0.02
  },
  {
    id: '1688483951266',
    userId: '1688483941265',
    type: 'bitcoin',
    address: '1BvBMSEYstWetqTFn5Au4m4GFg7xJaNVN2',
    label: 'BTC Main',
    createdAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(), // 30 days ago
    qrCode: null,
    displayOnProfile: true,
    donationCount: 7,
    donationTotal: 0.00578
  },
  {
    id: '1688483951267',
    userId: '1688483941265',
    type: 'ethereum',
    address: '0x742d35Cc6634C0532925a3b844Bc454e4438f44e',
    label: 'ETH Main',
    createdAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(), // 30 days ago
    qrCode: null,
    displayOnProfile: true,
    donationCount: 4,
    donationTotal: 0.15
  },
  {
    id: '1688483951268',
    userId: '1688483941265',
    type: 'terra-luna-classic',
    address: 'terra1x5h8cng70xqcaq7cqpj86cwlj6m7vt0ga0hz9z',
    label: 'LUNC Donations',
    createdAt: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString(), // 15 days ago
    qrCode: null,
    displayOnProfile: true,
    donationCount: 2,
    donationTotal: 1000
  }
];

async function seedData() {
  try {
    console.log('Seeding data...');

    // Check if data files exist, create if not
    try {
      await fs.access(USERS_FILE);
    } catch (error) {
      await fs.writeFile(USERS_FILE, JSON.stringify([]), 'utf8');
    }

    try {
      await fs.access(WALLETS_FILE);
    } catch (error) {
      await fs.writeFile(WALLETS_FILE, JSON.stringify([]), 'utf8');
    }

    // Write seed data
    await fs.writeFile(USERS_FILE, JSON.stringify(users, null, 2), 'utf8');
    await fs.writeFile(WALLETS_FILE, JSON.stringify(wallets, null, 2), 'utf8');

    console.log('Data seeded successfully!');
  } catch (error) {
    console.error('Error seeding data:', error);
  }
}

// Execute if this file is run directly
if (process.argv[1] === fileURLToPath(import.meta.url)) {
  seedData();
}

export default seedData;
