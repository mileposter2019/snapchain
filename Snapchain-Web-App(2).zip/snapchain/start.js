import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';
import { spawn } from 'child_process';
import seedData from './data/seed.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function initializeApp() {
  console.log('🚀 Initializing Snapchain...');

  // Ensure data directory exists
  const dataDir = path.join(__dirname, 'data');
  try {
    await fs.access(dataDir);
  } catch (error) {
    console.log('📁 Creating data directory...');
    await fs.mkdir(dataDir, { recursive: true });
  }

  // Seed data for development
  try {
    console.log('🌱 Seeding initial data...');
    await seedData();
  } catch (error) {
    console.error('❌ Error seeding data:', error);
  }

  // Start the server
  console.log('🔌 Starting server...');
  const server = spawn('node', ['server.js'], {
    stdio: 'inherit',
    env: { ...process.env }
  });

  server.on('error', (err) => {
    console.error('❌ Failed to start server:', err);
    process.exit(1);
  });

  process.on('SIGINT', () => {
    console.log('👋 Shutting down gracefully...');
    server.kill('SIGINT');
    process.exit(0);
  });
}

initializeApp().catch(error => {
  console.error('❌ Initialization failed:', error);
  process.exit(1);
});
