/**
 * Authentication middleware
 * Checks if a user is authenticated before allowing access to protected routes
 */

// Middleware to check if user is authenticated
export const checkAuthenticated = (req, res, next) => {
  if (req.session && req.session.user) {
    // User is authenticated
    return next();
  }

  // If not authenticated, redirect to login page
  res.redirect('/auth/login');
};

// Middleware to check if user is NOT authenticated (for login/register pages)
export const checkNotAuthenticated = (req, res, next) => {
  if (req.session && req.session.user) {
    // If already authenticated, redirect to dashboard
    return res.redirect('/dashboard');
  }

  // Not authenticated, proceed
  next();
};
