/**
 * Snapchain - Main JavaScript File
 * Contains all the interactive functionality for the app
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize all components
    initNavbar();
    initDropdowns();
    initCopyButtons();
    initDarkMode();
    initTooltips();
    initWalletCards();
    initScrollAnimations();
    initBackToTop();
    addDarkModeToggle(); // Add dark mode toggle button
});

/**
 * Navbar functionality
 */
function initNavbar() {
    const navbar = document.querySelector('.navbar');
    const navbarToggle = document.querySelector('.navbar-toggle');
    const navbarMenu = document.querySelector('.navbar-menu');

    // Toggle mobile menu
    if (navbarToggle) {
        navbarToggle.addEventListener('click', function() {
            navbarMenu.classList.toggle('active');
        });
    }

    // Change navbar style on scroll
    if (navbar) {
        window.addEventListener('scroll', function() {
            if (window.scrollY > 50) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });
    }

    // Close mobile menu when clicking outside
    document.addEventListener('click', function(event) {
        if (navbarMenu && navbarMenu.classList.contains('active') &&
            !event.target.closest('.navbar-menu') &&
            !event.target.closest('.navbar-toggle')) {
            navbarMenu.classList.remove('active');
        }
    });
}

/**
 * Dropdown functionality
 */
function initDropdowns() {
    const dropdowns = document.querySelectorAll('.dropdown');

    dropdowns.forEach(dropdown => {
        const toggle = dropdown.querySelector('.dropdown-toggle');

        if (toggle) {
            toggle.addEventListener('click', function(e) {
                e.preventDefault();
                dropdown.classList.toggle('active');

                // Close other dropdowns
                dropdowns.forEach(other => {
                    if (other !== dropdown) {
                        other.classList.remove('active');
                    }
                });
            });
        }
    });

    // Close dropdowns when clicking outside
    document.addEventListener('click', function(event) {
        if (!event.target.closest('.dropdown')) {
            dropdowns.forEach(dropdown => {
                dropdown.classList.remove('active');
            });
        }
    });
}

/**
 * Copy functionality for wallet addresses
 */
function initCopyButtons() {
    const copyButtons = document.querySelectorAll('.copy-address');

    copyButtons.forEach(button => {
        button.addEventListener('click', function() {
            const addressElement = this.closest('.wallet-address, .public-wallet-address');
            const address = addressElement.textContent.trim();

            // Create temporary textarea to copy text
            const textarea = document.createElement('textarea');
            textarea.value = address;
            textarea.style.position = 'fixed'; // Avoid scrolling to bottom
            document.body.appendChild(textarea);
            textarea.select();

            try {
                // Execute copy command
                document.execCommand('copy');

                // Show copied feedback
                this.setAttribute('data-original-icon', this.innerHTML);
                this.innerHTML = '<i class="fas fa-check"></i>';

                // Reset button after 2 seconds
                setTimeout(() => {
                    this.innerHTML = this.getAttribute('data-original-icon');
                }, 2000);

                // Show toast notification
                showToast('Address copied to clipboard!');
            } catch (err) {
                console.error('Failed to copy address:', err);
                showToast('Failed to copy address', 'error');
            }

            document.body.removeChild(textarea);
        });
    });
}

/**
 * Dark mode functionality
 */
function initDarkMode() {
    // Check for saved theme preference or use OS preference
    const prefersDarkScheme = window.matchMedia('(prefers-color-scheme: dark)');
    const savedTheme = localStorage.getItem('theme');

    if (savedTheme === 'dark' || (!savedTheme && prefersDarkScheme.matches)) {
        document.body.classList.add('dark-mode');
    }

    // Update all theme toggle buttons
    updateAllThemeToggleIcons();

    // Listen for OS theme changes
    prefersDarkScheme.addEventListener('change', (event) => {
        if (!localStorage.getItem('theme')) {
            if (event.matches) {
                document.body.classList.add('dark-mode');
            } else {
                document.body.classList.remove('dark-mode');
            }
            updateAllThemeToggleIcons();
        }
    });
}

/**
 * Update all theme toggle icons to match current theme
 */
function updateAllThemeToggleIcons() {
    const isDarkMode = document.body.classList.contains('dark-mode');
    const themeToggles = document.querySelectorAll('.theme-toggle');

    themeToggles.forEach(toggle => {
        toggle.innerHTML = isDarkMode ?
            '<i class="fas fa-sun"></i>' :
            '<i class="fas fa-moon"></i>';

        // Add appropriate aria-label for accessibility
        toggle.setAttribute('aria-label', isDarkMode ?
            'Switch to light mode' :
            'Switch to dark mode');

        // Add appropriate title for tooltip
        toggle.setAttribute('title', isDarkMode ?
            'Switch to light mode' :
            'Switch to dark mode');
    });
}

/**
 * Add dark mode toggle button
 */
function addDarkModeToggle() {
    // Only add if it doesn't exist already
    if (!document.querySelector('.theme-toggle-container')) {
        const toggleContainer = document.createElement('div');
        toggleContainer.className = 'theme-toggle-container';

        const themeToggle = document.createElement('button');
        themeToggle.className = 'theme-toggle';
        themeToggle.setAttribute('aria-label', 'Toggle dark mode');
        themeToggle.setAttribute('title', 'Toggle dark mode');

        // Set initial icon based on current theme
        const isDarkMode = document.body.classList.contains('dark-mode');
        themeToggle.innerHTML = isDarkMode ?
            '<i class="fas fa-sun"></i>' :
            '<i class="fas fa-moon"></i>';

        // Add click event listener
        themeToggle.addEventListener('click', toggleDarkMode);

        // Add to container and then to body
        toggleContainer.appendChild(themeToggle);
        document.body.appendChild(toggleContainer);
    }
}

/**
 * Toggle dark mode on button click
 */
function toggleDarkMode() {
    const isDarkMode = document.body.classList.toggle('dark-mode');

    // Save preference
    localStorage.setItem('theme', isDarkMode ? 'dark' : 'light');

    // Update all toggle buttons
    updateAllThemeToggleIcons();

    // Show notification
    showToast(`${isDarkMode ? 'Dark' : 'Light'} mode activated!`);
}

/**
 * Tooltip functionality
 */
function initTooltips() {
    const tooltips = document.querySelectorAll('[data-tooltip]');

    tooltips.forEach(tooltip => {
        // We're using CSS for the tooltip display
        // This just ensures the data-tooltip attribute is correctly set
        if (!tooltip.getAttribute('data-tooltip')) {
            tooltip.setAttribute('data-tooltip', tooltip.title);
            tooltip.removeAttribute('title');
        }

        tooltip.classList.add('tooltip');
    });
}

/**
 * Wallet card interactions
 */
function initWalletCards() {
    const walletCards = document.querySelectorAll('.wallet-card, .public-wallet');

    walletCards.forEach(card => {
        // Add wallet type as class if not already present
        const walletType = card.querySelector('.wallet-type, .public-wallet-type');
        if (walletType) {
            const type = walletType.textContent.trim().toLowerCase();
            if (!card.classList.contains(type)) {
                if (type.includes('bitcoin')) card.classList.add('bitcoin');
                if (type.includes('ethereum')) card.classList.add('ethereum');
                if (type.includes('terra') && type.includes('luna')) card.classList.add('terra-luna-classic');
            }
        }

        // Add wallet icons if they don't exist
        const walletIcon = card.querySelector('.wallet-icon, .public-wallet-icon');
        if (!walletIcon && card.classList.contains('bitcoin')) {
            addWalletIcon(card, 'fab fa-bitcoin', 'bitcoin');
        } else if (!walletIcon && card.classList.contains('ethereum')) {
            addWalletIcon(card, 'fab fa-ethereum', 'ethereum');
        } else if (!walletIcon && card.classList.contains('terra-luna-classic')) {
            addWalletIcon(card, 'fas fa-globe', 'terra-luna-classic');
        }

        // Add copy button to address
        const addressElement = card.querySelector('.wallet-address, .public-wallet-address');
        if (addressElement && !addressElement.querySelector('.copy-address')) {
            const copyButton = document.createElement('button');
            copyButton.className = 'copy-address';
            copyButton.innerHTML = '<i class="fas fa-clipboard"></i>';
            copyButton.setAttribute('aria-label', 'Copy address');
            addressElement.appendChild(copyButton);
        }
    });

    function addWalletIcon(card, iconClass, walletType) {
        const header = card.querySelector('.wallet-header, .public-wallet-header');
        if (!header) return;

        const iconDiv = document.createElement('div');
        iconDiv.className = walletType === 'public-wallet' ? 'public-wallet-icon' : 'wallet-icon';
        iconDiv.innerHTML = `<i class="${iconClass}"></i>`;

        if (header.firstChild) {
            header.insertBefore(iconDiv, header.firstChild);
        } else {
            header.appendChild(iconDiv);
        }
    }
}

/**
 * Scroll animations
 */
function initScrollAnimations() {
    const animatedElements = document.querySelectorAll('.animate-on-scroll');

    // Function to check if an element is in viewport
    function isInViewport(element) {
        const rect = element.getBoundingClientRect();
        return (
            rect.top <= (window.innerHeight || document.documentElement.clientHeight) * 0.9 &&
            rect.bottom >= 0
        );
    }

    // Function to add animation class when element is in viewport
    function animateOnScroll() {
        animatedElements.forEach(element => {
            if (isInViewport(element) && !element.classList.contains('animated')) {
                element.classList.add('animate-fade-in-up', 'animated');
            }
        });
    }

    // Run on scroll and on initial load
    window.addEventListener('scroll', animateOnScroll);
    animateOnScroll();
}

/**
 * Back to top button
 */
function initBackToTop() {
    const backToTopButton = document.getElementById('backToTop');

    if (backToTopButton) {
        // Show/hide button based on scroll position
        window.addEventListener('scroll', function() {
            if (window.scrollY > 300) {
                backToTopButton.classList.add('show');
            } else {
                backToTopButton.classList.remove('show');
            }
        });

        // Scroll to top on click
        backToTopButton.addEventListener('click', function() {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    }
}

/**
 * Toast notification
 */
function showToast(message, type = 'success', duration = 3000) {
    // Create toast container if it doesn't exist
    let toastContainer = document.getElementById('toast-container');

    if (!toastContainer) {
        toastContainer = document.createElement('div');
        toastContainer.id = 'toast-container';
        document.body.appendChild(toastContainer);

        // Add style for toast container
        toastContainer.style.position = 'fixed';
        toastContainer.style.bottom = '20px';
        toastContainer.style.right = '20px';
        toastContainer.style.zIndex = '9999';
    }

    // Create toast element
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
        <div class="toast-content">
            <i class="fas ${type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'}"></i>
            <span>${message}</span>
        </div>
        <button class="toast-close"><i class="fas fa-times"></i></button>
    `;

    // Style the toast
    toast.style.backgroundColor = type === 'success' ? '#28a745' : '#dc3545';
    toast.style.color = 'white';
    toast.style.padding = '12px 16px';
    toast.style.borderRadius = '4px';
    toast.style.marginTop = '10px';
    toast.style.boxShadow = '0 3px 10px rgba(0, 0, 0, 0.2)';
    toast.style.display = 'flex';
    toast.style.alignItems = 'center';
    toast.style.justifyContent = 'space-between';
    toast.style.minWidth = '250px';
    toast.style.transform = 'translateX(100%)';
    toast.style.opacity = '0';
    toast.style.transition = 'all 0.3s ease';

    // Add toast to container
    toastContainer.appendChild(toast);

    // Animate toast in
    setTimeout(() => {
        toast.style.transform = 'translateX(0)';
        toast.style.opacity = '1';
    }, 10);

    // Close button functionality
    const closeButton = toast.querySelector('.toast-close');
    if (closeButton) {
        closeButton.addEventListener('click', () => {
            closeToast(toast);
        });
    }

    // Auto close after duration
    setTimeout(() => {
        closeToast(toast);
    }, duration);

    function closeToast(toast) {
        toast.style.transform = 'translateX(100%)';
        toast.style.opacity = '0';

        // Remove toast after animation
        setTimeout(() => {
            toast.remove();
        }, 300);
    }
}

/**
 * Wallet QR code generator
 * (This function would be used when displaying wallet details)
 */
function generateQRCode(address, elementId) {
    // Check if QRCode library is available
    if (typeof QRCode !== 'undefined') {
        const qrCodeElement = document.getElementById(elementId);

        if (qrCodeElement) {
            // Clear previous QR code
            qrCodeElement.innerHTML = '';

            // Generate new QR code
            new QRCode(qrCodeElement, {
                text: address,
                width: 180,
                height: 180,
                colorDark: '#000000',
                colorLight: '#ffffff',
                correctLevel: QRCode.CorrectLevel.H
            });
        }
    } else {
        console.error('QRCode library not loaded');
    }
}
