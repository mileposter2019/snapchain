import fs from 'fs/promises';
import bcrypt from 'bcrypt';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const USERS_FILE = path.join(__dirname, '../data/users.json');

// Subscription plans
export const SUBSCRIPTION_PLANS = {
  FREE: 'free',
  BASIC: 'basic', // $5/month
  PRO: 'pro'      // $10/month
};

// Subscription features
export const SUBSCRIPTION_FEATURES = {
  [SUBSCRIPTION_PLANS.FREE]: {
    maxWallets: 3,
    analytics: false,
    customDomain: false,
    price: 0
  },
  [SUBSCRIPTION_PLANS.BASIC]: {
    maxWallets: 10,
    analytics: true,
    customDomain: false,
    price: 5
  },
  [SUBSCRIPTION_PLANS.PRO]: {
    maxWallets: 50,
    analytics: true,
    customDomain: true,
    price: 10
  }
};

export default class User {
  constructor(data) {
    this.id = data.id;
    this.username = data.username;
    this.email = data.email;
    this.password = data.password; // Hashed password
    this.profileUrl = data.profileUrl || this.username;
    this.createdAt = data.createdAt || new Date().toISOString();
    this.subscription = data.subscription || SUBSCRIPTION_PLANS.FREE;
    this.subscriptionExpiry = data.subscriptionExpiry || null;
    this.stripeCustomerId = data.stripeCustomerId || null;
    this.lastLogin = data.lastLogin || null;
    this.pageViews = data.pageViews || 0;
  }

  // Save user to JSON file
  async save() {
    try {
      let users = JSON.parse(await fs.readFile(USERS_FILE, 'utf8'));

      const existingIndex = users.findIndex(user => user.id === this.id);

      if (existingIndex !== -1) {
        // Update existing user
        users[existingIndex] = this;
      } else {
        // Add new user
        users.push(this);
      }

      await fs.writeFile(USERS_FILE, JSON.stringify(users, null, 2));
      return true;
    } catch (error) {
      console.error('Error saving user:', error);
      return false;
    }
  }

  // Find user by ID
  static async findById(id) {
    try {
      const users = JSON.parse(await fs.readFile(USERS_FILE, 'utf8'));
      const user = users.find(user => user.id === id);

      return user ? new User(user) : null;
    } catch (error) {
      console.error('Error finding user by ID:', error);
      return null;
    }
  }

  // Find user by email
  static async findByEmail(email) {
    try {
      const users = JSON.parse(await fs.readFile(USERS_FILE, 'utf8'));
      const user = users.find(user => user.email.toLowerCase() === email.toLowerCase());

      return user ? new User(user) : null;
    } catch (error) {
      console.error('Error finding user by email:', error);
      return null;
    }
  }

  // Find user by username
  static async findByUsername(username) {
    try {
      const users = JSON.parse(await fs.readFile(USERS_FILE, 'utf8'));
      const user = users.find(user => user.username.toLowerCase() === username.toLowerCase());

      return user ? new User(user) : null;
    } catch (error) {
      console.error('Error finding user by username:', error);
      return null;
    }
  }

  // Find user by profile URL
  static async findByProfileUrl(profileUrl) {
    try {
      const users = JSON.parse(await fs.readFile(USERS_FILE, 'utf8'));
      const user = users.find(user => user.profileUrl.toLowerCase() === profileUrl.toLowerCase());

      return user ? new User(user) : null;
    } catch (error) {
      console.error('Error finding user by profile URL:', error);
      return null;
    }
  }

  // Create new user (register)
  static async create({ username, email, password, profileUrl }) {
    try {
      // Check if username or email already exists
      const existingUser = await User.findByEmail(email) || await User.findByUsername(username);

      if (existingUser) {
        return { success: false, message: 'Username or email already exists' };
      }

      // Generate unique ID
      const id = Date.now().toString();

      // Hash password
      const hashedPassword = await bcrypt.hash(password, 10);

      // Create new user
      const newUser = new User({
        id,
        username,
        email,
        password: hashedPassword,
        profileUrl: profileUrl || username,
      });

      // Save user
      await newUser.save();

      return { success: true, user: newUser };
    } catch (error) {
      console.error('Error creating user:', error);
      return { success: false, message: 'Error creating user' };
    }
  }

  // Authenticate user (login)
  static async authenticate(email, password) {
    try {
      // Find user by email
      const user = await User.findByEmail(email);

      if (!user) {
        return { success: false, message: 'Invalid email or password' };
      }

      // Compare passwords
      const match = await bcrypt.compare(password, user.password);

      if (!match) {
        return { success: false, message: 'Invalid email or password' };
      }

      // Update last login
      user.lastLogin = new Date().toISOString();
      await user.save();

      return { success: true, user };
    } catch (error) {
      console.error('Error authenticating user:', error);
      return { success: false, message: 'Error authenticating user' };
    }
  }

  // Update user data
  async update(data) {
    try {
      // Update user data
      Object.keys(data).forEach(key => {
        // Don't update id and password here
        if (key !== 'id' && key !== 'password') {
          this[key] = data[key];
        }
      });

      // Save updated user
      await this.save();

      return { success: true, user: this };
    } catch (error) {
      console.error('Error updating user:', error);
      return { success: false, message: 'Error updating user' };
    }
  }

  // Update user password
  async updatePassword(currentPassword, newPassword) {
    try {
      // Verify current password
      const match = await bcrypt.compare(currentPassword, this.password);

      if (!match) {
        return { success: false, message: 'Current password is incorrect' };
      }

      // Hash new password
      this.password = await bcrypt.hash(newPassword, 10);

      // Save updated user
      await this.save();

      return { success: true };
    } catch (error) {
      console.error('Error updating password:', error);
      return { success: false, message: 'Error updating password' };
    }
  }

  // Update subscription
  async updateSubscription(plan, expiryDate, stripeCustomerId) {
    try {
      this.subscription = plan;
      this.subscriptionExpiry = expiryDate;

      if (stripeCustomerId) {
        this.stripeCustomerId = stripeCustomerId;
      }

      // Save updated user
      await this.save();

      return { success: true, user: this };
    } catch (error) {
      console.error('Error updating subscription:', error);
      return { success: false, message: 'Error updating subscription' };
    }
  }

  // Increment page views
  async incrementPageViews() {
    this.pageViews += 1;
    await this.save();
    return this.pageViews;
  }
}
