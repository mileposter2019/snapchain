import express from 'express';
import User from '../models/User.js';
import { checkNotAuthenticated } from '../middleware/auth.js';

const router = express.Router();

// Login page
router.get('/login', checkNotAuthenticated, (req, res) => {
  res.render('auth/login', {
    title: 'Login - Snapchain',
    error: req.query.error || null,
    success: req.query.success || null
  });
});

// Login POST
router.post('/login', checkNotAuthenticated, async (req, res) => {
  try {
    const { email, password } = req.body;

    // Validate input
    if (!email || !password) {
      return res.redirect('/auth/login?error=Please+provide+both+email+and+password');
    }

    // Authenticate user
    const result = await User.authenticate(email, password);

    if (!result.success) {
      return res.redirect(`/auth/login?error=${encodeURIComponent(result.message)}`);
    }

    // Set session
    req.session.user = {
      id: result.user.id,
      username: result.user.username,
      email: result.user.email,
      profileUrl: result.user.profileUrl,
      subscription: result.user.subscription
    };

    // Redirect to dashboard
    res.redirect('/dashboard');
  } catch (error) {
    console.error('Login error:', error);
    res.redirect('/auth/login?error=An+unexpected+error+occurred');
  }
});

// Register page
router.get('/register', checkNotAuthenticated, (req, res) => {
  res.render('auth/register', {
    title: 'Register - Snapchain',
    error: req.query.error || null
  });
});

// Register POST
router.post('/register', checkNotAuthenticated, async (req, res) => {
  try {
    const { username, email, password, confirmPassword, profileUrl } = req.body;

    // Validate input
    if (!username || !email || !password) {
      return res.redirect('/auth/register?error=Please+fill+all+required+fields');
    }

    if (password !== confirmPassword) {
      return res.redirect('/auth/register?error=Passwords+do+not+match');
    }

    // Validate username (alphanumeric and hyphens only)
    if (!/^[a-zA-Z0-9-]+$/.test(username)) {
      return res.redirect('/auth/register?error=Username+can+only+contain+letters,+numbers,+and+hyphens');
    }

    // Create user
    const result = await User.create({
      username,
      email,
      password,
      profileUrl: profileUrl || username
    });

    if (!result.success) {
      return res.redirect(`/auth/register?error=${encodeURIComponent(result.message)}`);
    }

    // Redirect to login with success message
    res.redirect('/auth/login?success=Registration+successful.+Please+log+in.');
  } catch (error) {
    console.error('Registration error:', error);
    res.redirect('/auth/register?error=An+unexpected+error+occurred');
  }
});

// Logout
router.get('/logout', (req, res) => {
  // Clear session
  req.session.destroy(err => {
    if (err) {
      console.error('Error destroying session:', err);
    }

    // Redirect to home
    res.redirect('/');
  });
});

// Forgot password page
router.get('/forgot-password', checkNotAuthenticated, (req, res) => {
  res.render('auth/forgot-password', {
    title: 'Forgot Password - Snapchain',
    error: req.query.error || null,
    success: req.query.success || null
  });
});

// Forgot password POST
router.post('/forgot-password', checkNotAuthenticated, async (req, res) => {
  try {
    const { email } = req.body;

    // Validate input
    if (!email) {
      return res.redirect('/auth/forgot-password?error=Please+provide+your+email');
    }

    // Check if user exists
    const user = await User.findByEmail(email);

    if (!user) {
      // Don't reveal that the email doesn't exist (security)
      return res.redirect('/auth/forgot-password?success=If+your+email+is+registered,+you+will+receive+instructions+to+reset+your+password');
    }

    // In a real application, you would send an email with a reset link
    // For now, just show a success message
    res.redirect('/auth/forgot-password?success=If+your+email+is+registered,+you+will+receive+instructions+to+reset+your+password');
  } catch (error) {
    console.error('Forgot password error:', error);
    res.redirect('/auth/forgot-password?error=An+unexpected+error+occurred');
  }
});

export default router;
