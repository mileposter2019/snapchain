import express from 'express';
import Wallet, { WALLET_TYPES } from '../models/Wallet.js';
import User, { SUBSCRIPTION_FEATURES, SUBSCRIPTION_PLANS } from '../models/User.js';

const router = express.Router();

// List wallets
router.get('/', async (req, res) => {
  try {
    // Get user
    const user = await User.findById(req.session.user.id);

    if (!user) {
      return res.redirect('/auth/logout');
    }

    // Get wallets
    const wallets = await Wallet.findByUserId(user.id);

    // Get subscription features
    const subscriptionFeatures = SUBSCRIPTION_FEATURES[user.subscription];

    res.render('wallets/index', {
      title: 'My Wallets - Snapchain',
      user: req.session.user,
      wallets,
      walletTypes: WALLET_TYPES,
      subscriptionFeatures,
      maxWallets: subscriptionFeatures.maxWallets,
      remainingWallets: subscriptionFeatures.maxWallets - wallets.length,
      error: req.query.error || null,
      success: req.query.success || null
    });
  } catch (error) {
    console.error('Error listing wallets:', error);
    res.render('wallets/index', {
      title: 'My Wallets - Snapchain',
      user: req.session.user,
      wallets: [],
      walletTypes: WALLET_TYPES,
      subscriptionFeatures: SUBSCRIPTION_FEATURES[SUBSCRIPTION_PLANS.FREE],
      maxWallets: SUBSCRIPTION_FEATURES[SUBSCRIPTION_PLANS.FREE].maxWallets,
      remainingWallets: SUBSCRIPTION_FEATURES[SUBSCRIPTION_PLANS.FREE].maxWallets,
      error: 'An error occurred while fetching your wallets'
    });
  }
});

// Add wallet form
router.get('/add', async (req, res) => {
  try {
    // Get user
    const user = await User.findById(req.session.user.id);

    if (!user) {
      return res.redirect('/auth/logout');
    }

    // Get wallets
    const wallets = await Wallet.findByUserId(user.id);

    // Get subscription features
    const subscriptionFeatures = SUBSCRIPTION_FEATURES[user.subscription];

    // Check if user has reached the maximum number of wallets
    if (wallets.length >= subscriptionFeatures.maxWallets) {
      return res.redirect('/wallets?error=You+have+reached+the+maximum+number+of+wallets+for+your+subscription+plan.+Please+upgrade+to+add+more+wallets.');
    }

    res.render('wallets/add', {
      title: 'Add Wallet - Snapchain',
      user: req.session.user,
      walletTypes: WALLET_TYPES,
      error: req.query.error || null
    });
  } catch (error) {
    console.error('Error loading add wallet form:', error);
    res.redirect('/wallets?error=An+error+occurred+while+loading+the+add+wallet+form');
  }
});

// Add wallet POST
router.post('/add', async (req, res) => {
  try {
    const { type, address, label, displayOnProfile } = req.body;

    // Validate input
    if (!type || !address) {
      return res.redirect('/wallets/add?error=Please+provide+both+wallet+type+and+address');
    }

    // Check if wallet type is valid
    if (!Object.values(WALLET_TYPES).includes(type)) {
      return res.redirect('/wallets/add?error=Invalid+wallet+type');
    }

    // Get user
    const user = await User.findById(req.session.user.id);

    if (!user) {
      return res.redirect('/auth/logout');
    }

    // Get wallets
    const wallets = await Wallet.findByUserId(user.id);

    // Get subscription features
    const subscriptionFeatures = SUBSCRIPTION_FEATURES[user.subscription];

    // Check if user has reached the maximum number of wallets
    if (wallets.length >= subscriptionFeatures.maxWallets) {
      return res.redirect('/wallets?error=You+have+reached+the+maximum+number+of+wallets+for+your+subscription+plan.+Please+upgrade+to+add+more+wallets.');
    }

    // Create wallet
    const result = await Wallet.create({
      userId: user.id,
      type,
      address,
      label: label || '',
      displayOnProfile: displayOnProfile === 'on'
    });

    if (!result.success) {
      return res.redirect(`/wallets/add?error=${encodeURIComponent(result.message)}`);
    }

    // Redirect to wallets with success message
    res.redirect('/wallets?success=Wallet+added+successfully');
  } catch (error) {
    console.error('Error adding wallet:', error);
    res.redirect('/wallets/add?error=An+unexpected+error+occurred');
  }
});

// Edit wallet form
router.get('/edit/:id', async (req, res) => {
  try {
    const { id } = req.params;

    // Get wallet
    const wallet = await Wallet.findById(id);

    if (!wallet) {
      return res.redirect('/wallets?error=Wallet+not+found');
    }

    // Check if wallet belongs to user
    if (wallet.userId !== req.session.user.id) {
      return res.redirect('/wallets?error=You+do+not+have+permission+to+edit+this+wallet');
    }

    res.render('wallets/edit', {
      title: 'Edit Wallet - Snapchain',
      user: req.session.user,
      wallet,
      walletTypes: WALLET_TYPES,
      error: req.query.error || null
    });
  } catch (error) {
    console.error('Error loading edit wallet form:', error);
    res.redirect('/wallets?error=An+error+occurred+while+loading+the+edit+wallet+form');
  }
});

// Edit wallet POST
router.post('/edit/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { label, displayOnProfile } = req.body;

    // Get wallet
    const wallet = await Wallet.findById(id);

    if (!wallet) {
      return res.redirect('/wallets?error=Wallet+not+found');
    }

    // Check if wallet belongs to user
    if (wallet.userId !== req.session.user.id) {
      return res.redirect('/wallets?error=You+do+not+have+permission+to+edit+this+wallet');
    }

    // Update wallet
    const result = await wallet.update({
      label,
      displayOnProfile: displayOnProfile === 'on'
    });

    if (!result.success) {
      return res.redirect(`/wallets/edit/${id}?error=${encodeURIComponent(result.message)}`);
    }

    // Redirect to wallets with success message
    res.redirect('/wallets?success=Wallet+updated+successfully');
  } catch (error) {
    console.error('Error updating wallet:', error);
    res.redirect(`/wallets/edit/${req.params.id}?error=An+unexpected+error+occurred`);
  }
});

// Delete wallet
router.post('/delete/:id', async (req, res) => {
  try {
    const { id } = req.params;

    // Get wallet
    const wallet = await Wallet.findById(id);

    if (!wallet) {
      return res.redirect('/wallets?error=Wallet+not+found');
    }

    // Check if wallet belongs to user
    if (wallet.userId !== req.session.user.id) {
      return res.redirect('/wallets?error=You+do+not+have+permission+to+delete+this+wallet');
    }

    // Delete wallet
    const result = await wallet.delete();

    if (!result.success) {
      return res.redirect(`/wallets?error=${encodeURIComponent(result.message)}`);
    }

    // Redirect to wallets with success message
    res.redirect('/wallets?success=Wallet+deleted+successfully');
  } catch (error) {
    console.error('Error deleting wallet:', error);
    res.redirect('/wallets?error=An+unexpected+error+occurred');
  }
});

// Regenerate QR code
router.get('/regenerate-qr/:id', async (req, res) => {
  try {
    const { id } = req.params;

    // Get wallet
    const wallet = await Wallet.findById(id);

    if (!wallet) {
      return res.redirect('/wallets?error=Wallet+not+found');
    }

    // Check if wallet belongs to user
    if (wallet.userId !== req.session.user.id) {
      return res.redirect('/wallets?error=You+do+not+have+permission+to+regenerate+QR+code+for+this+wallet');
    }

    // Regenerate QR code
    await wallet.generateQRCode();

    // Redirect to wallets with success message
    res.redirect('/wallets?success=QR+code+regenerated+successfully');
  } catch (error) {
    console.error('Error regenerating QR code:', error);
    res.redirect('/wallets?error=An+unexpected+error+occurred');
  }
});

export default router;
